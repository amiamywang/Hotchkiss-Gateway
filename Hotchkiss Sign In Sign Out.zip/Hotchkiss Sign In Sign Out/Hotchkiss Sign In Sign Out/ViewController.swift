//
//  ViewController.swift
//  Hotchkiss Sign In Sign Out
//
//  Created by Student on 11/15/18.
//  Copyright © 2018 Priyanka Kumar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var facultyLogButton: UIButton!
    @IBOutlet weak var studentLogButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func stuButtonPressed(_ sender: Any) {
    }
    
    @IBAction func facButtonPressed(_ sender: Any) {
    }
}

